package interfaces.futbol;

public interface Jugar_I {
    
    public void HacerGol();
    public void cometerFalta();

}

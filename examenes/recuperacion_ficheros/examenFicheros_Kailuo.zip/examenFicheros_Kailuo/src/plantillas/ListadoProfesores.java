package plantillas;

import java.util.List;

public class ListadoProfesores {

    // Atributos
    private List<Profesores> profesores;

    // Constructor
    public ListadoProfesores() {

    }

    // getter and setter
    public List<Profesores> getProfesores() {
        return profesores;
    }

    public void setProfesores(List<Profesores> profesores) {
        this.profesores = profesores;
    }


    
}

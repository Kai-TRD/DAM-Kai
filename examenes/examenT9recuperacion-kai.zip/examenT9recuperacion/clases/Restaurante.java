package examenes.examenT9recuperacion.clases;

public class Restaurante {

    public Carta getCarta() {
        return null;
    }

    public void addProducto(int i, Producto producto) {
    }

    public void deleteProducto(int i, Producto producto) {
    }
    
}

import modelos.Ferreteria;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("+--- FERRETERIA ---+");

        Ferreteria ferreteria = new Ferreteria();

        ferreteria.crearFacturaCliente();












    }
}

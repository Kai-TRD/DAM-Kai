package exceptions;

public class ExcepcionEventoSinStock {

}

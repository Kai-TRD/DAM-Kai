package clasesHerencia.frioMijas;
public class pruebas {
    public static void main(String[] args) {
        /*
            Minibar: tiene el número de baldas y el consumo serán las frigorias * 2
            Frigorífico: volumen() + consumo= frigorias * 3
            Arcón: tipoApertura + consumo= frigorias * 2
            Cámara: temperaturaMinimaMax + volumen() + consumo = frigorias * 5
        */
    }
}
